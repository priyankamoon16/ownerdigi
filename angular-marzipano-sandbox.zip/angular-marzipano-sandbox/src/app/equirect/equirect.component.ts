import { Component, ElementRef, OnInit, ViewChild } from '@angular/core'
import * as Marzipano from 'marzipano'

@Component({
  selector: 'app-equirect',
  templateUrl: './equirect.component.html'
})
export class EquirectComponent implements OnInit {


  @ViewChild('pano') pano: ElementRef

  constructor() { }

  ngOnInit(): void { }




  ngAfterViewInit(): void {

     const panoElement = this.pano.nativeElement

    // var viewerOpts = {
    //   controls: {
    //     mouseViewMode: 'drag'
    //   }
    // }

    // const viewer = new Marzipano.Viewer(panoElement, viewerOpts)

    // var autorotate = Marzipano.autorotate({
    //   yawSpeed: 0.1,         // Yaw rotation speed
    //   targetPitch: 0,        // Pitch value to converge to
    //   targetFov: Math.PI/2   // Fov value to converge to
    // });

    // // Autorotate will start after 3s of idle time
    // viewer.setIdleMovement(10000, autorotate);
    // // Disable idle movement
    // viewer.setIdleMovement(Infinity);

    // // Start autorotation immediately
    // viewer.startMovement(autorotate);
    // // Stop any ongoing automatic movement
    // viewer.stopMovement();

    // const limiter = Marzipano.RectilinearView.limit.traditional(1024, 100 * Math.PI / 180)
    // const view = new Marzipano.RectilinearView({ yaw: Math.PI }, limiter);

    // const geometry = new Marzipano.EquirectGeometry([
    //   {
    //     "tileSize": 256,
    //     "size": 256,
    //     "fallbackOnly": true
    //   },
    //   {
    //     "tileSize": 512,
    //     "size": 512
    //   },
    //   {
    //     "tileSize": 512,
    //     "size": 1024
    //   }
    // ])
    //const source = Marzipano.ImageUrlSource.fromString("../../assets/360images/Balcony 2.JPG")
    //const source = Marzipano.ImageUrlSource.fromString("../../assets/angra.jpg")
    // var source = Marzipano.ImageUrlSource.fromString("../assets/tiles/pano/{z}/{y}/{x}.jpg")




    // var scene = viewer.createScene({
    //   source: source,
    //   geometry: geometry,
    //   view: view,
    //   pinFirstLevel: true
    // })


    // scene.switchTo({
    //   transitionDuration: 1000
    // });


    // var destinationViewParameters = {
    //   yaw: 10 * Math.PI/180,
    //   pitch: 15 * Math.PI/180,
    //   fov: 60 * Math.PI/180
    // };

    // var options = {
    //   transitionDuration: 2000
    // }

    // scene.lookTo(destinationViewParameters, options);


      }
}



// (function () {
//   // const queryString = window.location.search;
//   // console.log(queryString);
//   // const urlParams = new URLSearchParams(queryString);
//   // const product = urlParams.get("product");
//   // console.log(product);

//   var Marzipano = Marzipano;
//   //var bowser = window.bowser;
//   //var screenfull = window.screenfull;
//   var settings= {"autorotateEnabled": true,
//   "fullscreenButton": false,
//   "mouseViewMode": "drag",
//   "viewControlButtons": false
// }
//   var data = [{
//   "faceSize": 1344,
//   "id": "0-entrance",
//   infoHotspots: [
//   {
//   "pitch": 1.5707963267948966,
//   "text": "",
//   "title": "",
//   "yaw": -0.04796782370210373
//   }],
//   "initialViewParameters": {"yaw": 0.0653533241389539, "pitch": -0.13396813078380632, "fov": 1.3239187874773195},
//   levels: [
//  {"tileSize": 256, "size": 256, "fallbackOnly": true},
// {"tileSize": 512, "size": 512},
//   {"tileSize": 512, "size": 1024},
//  {"tileSize": 512, size: 2048}
//   ],
//   "linkHotspots": [{
//   "pitch": -0.12799110827074678,
//   "rotation": 0,
//   "target": "1-living-room",
//   "yaw": -0.16570879518475756
//   }],
//   "name": "Entrance"
//   },
//   {
//   "faceSize": 1344,
//   "id": "1-living-room",
//   "infoHotspots": [
//   {
//   "pitch": 1.5707963267948966,
//   "text": "",
//   "title": "",
//   "yaw": -0.04796782370210373
//   }],
//   "initialViewParameters": {yaw: 0.08054546602044255, pitch: 0.06931540521347834, fov: 1.3239187874773195},
//   "levels": [
//   {"tileSize": 256, "size": 256, "fallbackOnly": true},
//   {"tileSize": 512, "size": 512},
//   {"tileSize": 512, "size": 1024},
//   {"tileSize": 512, size: 2048}
//   ],
//   "linkHotspots": [
//   {yaw: -3.10104480847086, pitch: 0.015182680355305678, rotation: 0, target: "0-entrance"},
//   {yaw: 0.9656506825359834, pitch: -0.10804447273196338, rotation: 0, target: "2-living-room-balcony"},
//   {yaw: -1.7538027692558824, pitch: -0.016039785555811648, rotation: 0, target: "3-kitchen"},
//   {yaw: 0.2670558138755741, pitch: 0.363067892150557, rotation: 3.141592653589793, target: "5-passage-area"}
//   ],
//   "name": "Living room"
//   }];

//   // Grab elements from DOM.
//   var panoElement = document.querySelector("#pano");
//   var sceneNameElement = document.querySelector("#titleBar .sceneName");
//   var sceneListElement = document.querySelector("#sceneList");
//   var sceneElements = document.querySelectorAll("#sceneList .scene");
//   var sceneListToggleElement = document.querySelector("#sceneListToggle");
//   var autorotateToggleElement = document.querySelector("#autorotateToggle");
//   var fullscreenToggleElement = document.querySelector("#fullscreenToggle");

//   // Detect desktop or mobile mode.
//   if (window.matchMedia) {
//     var setMode = function () {
//       if (mql.matches) {
//         document.body.classList.remove("desktop");
//         document.body.classList.add("mobile");
//       } else {
//         document.body.classList.remove("mobile");
//         document.body.classList.add("desktop");
//       }
//     };
//     var mql = matchMedia("(max-width: 500px), (max-height: 500px)");
//     setMode();
//     mql.addListener(setMode);
//   } else {
//     document.body.classList.add("desktop");
//   }

//   // Detect whether we are on a touch device.
//   document.body.classList.add("no-touch");
//   window.addEventListener("touchstart", function () {
//     document.body.classList.remove("no-touch");
//     document.body.classList.add("touch");
//   });

//   // Use tooltip fallback mode on IE < 11.
//   // if (bowser.msie && parseFloat(bowser.version) < 11) {
//   //   document.body.classList.add("tooltip-fallback");
//   // }

//   // Viewer options.
//   var viewerOpts = {
//     controls: {
//       mouseViewMode: "drag",
//     },
//   };

//   // Initialize viewer.
//   var viewer = new Marzipano.Viewer(panoElement, viewerOpts);

//   // Create scenes.
//   var scenes = data.map(function (data) {
//     var source = Marzipano.ImageUrlSource.fromString(+ data.id + "/{z}/{f}/{y}/{x}.jpg"
//     );
//     var geometry = new Marzipano.CubeGeometry(data.levels);

//     var limiter = Marzipano.RectilinearView.limit.traditional(
//       data.faceSize,
//       (100 * Math.PI) / 180,
//       (120 * Math.PI) / 180
//     );
//     var view = new Marzipano.RectilinearView(
//       data.initialViewParameters,
//       limiter
//     );

//     var scene = viewer.createScene({
//       source: source,
//       geometry: geometry,
//       view: view,
//       pinFirstLevel: true,
//     });

//     // Create link hotspots.
//     data.linkHotspots.forEach(function (hotspot) {
//       var element = createLinkHotspotElement(hotspot);
//       scene
//         .hotspotContainer()
//         .createHotspot(element, { yaw: hotspot.yaw, pitch: hotspot.pitch });
//     });

//     // Create info hotspots.
//     data.infoHotspots.forEach(function (hotspot) {
//       var element = createInfoHotspotElement(hotspot);
//       scene
//         .hotspotContainer()
//         .createHotspot(element, { yaw: hotspot.yaw, pitch: hotspot.pitch });
//     });

//     return {
//       data: data,
//       scene: scene,
//       view: view,
//     };
//   });

//   // Set up autorotate, if enabled.
//   var autorotate = Marzipano.autorotate({
//     yawSpeed: 0.03,
//     targetPitch: 0,
//     targetFov: Math.PI / 2,
//   });
//   if (settings.autorotateEnabled) {
//     autorotateToggleElement.classList.add("enabled");
//   }

//   // Set handler for autorotate toggle.
//   autorotateToggleElement.addEventListener("click", toggleAutorotate);

//   // Set up fullscreen mode, if supported.
//   // if (screenfull.enabled && data.settings.fullscreenButton) {
//   //   document.body.classList.add("fullscreen-enabled");
//   //   fullscreenToggleElement.addEventListener("click", function () {
//   //     screenfull.toggle();
//   //   });
//   //   screenfull.on("change", function () {
//   //     if (screenfull.isFullscreen) {
//   //       fullscreenToggleElement.classList.add("enabled");
//   //     } else {
//   //       fullscreenToggleElement.classList.remove("enabled");
//   //     }
//   //   });
//   // } else {
//   //   document.body.classList.add("fullscreen-disabled");
//   // }

//   // Set handler for scene list toggle.
//   sceneListToggleElement.addEventListener("click", toggleSceneList);

//   // Start with the scene list open on desktop.
//   if (!document.body.classList.contains("mobile")) {
//     showSceneList();
//   }

//   // Set handler for scene switch.
//   scenes.forEach(function (scene) {
//     var el = document.querySelector(
//       '#sceneList .scene[data-id="' + scene.data.id + '"]'
//     );
//     el.addEventListener("click", function () {
//       switchScene(scene);
//       // On mobile, hide scene list after selecting a scene.
//       if (document.body.classList.contains("mobile")) {
//         hideSceneList();
//       }
//     });
//   });

//   // DOM elements for view controls.
//   var viewUpElement = document.querySelector("#viewUp");
//   var viewDownElement = document.querySelector("#viewDown");
//   var viewLeftElement = document.querySelector("#viewLeft");
//   var viewRightElement = document.querySelector("#viewRight");
//   var viewInElement = document.querySelector("#viewIn");
//   var viewOutElement = document.querySelector("#viewOut");

//   // Dynamic parameters for controls.
//   var velocity = 0.7;
//   var friction = 3;

//   // Associate view controls with elements.
//   var controls = viewer.controls();
//   controls.registerMethod(
//     "upElement",
//     new Marzipano.ElementPressControlMethod(
//       viewUpElement,
//       "y",
//       -velocity,
//       friction
//     ),
//     true
//   );
//   controls.registerMethod(
//     "downElement",
//     new Marzipano.ElementPressControlMethod(
//       viewDownElement,
//       "y",
//       velocity,
//       friction
//     ),
//     true
//   );
//   controls.registerMethod(
//     "leftElement",
//     new Marzipano.ElementPressControlMethod(
//       viewLeftElement,
//       "x",
//       -velocity,
//       friction
//     ),
//     true
//   );
//   controls.registerMethod(
//     "rightElement",
//     new Marzipano.ElementPressControlMethod(
//       viewRightElement,
//       "x",
//       velocity,
//       friction
//     ),
//     true
//   );
//   controls.registerMethod(
//     "inElement",
//     new Marzipano.ElementPressControlMethod(
//       viewInElement,
//       "zoom",
//       -velocity,
//       friction
//     ),
//     true
//   );
//   controls.registerMethod(
//     "outElement",
//     new Marzipano.ElementPressControlMethod(
//       viewOutElement,
//       "zoom",
//       velocity,
//       friction
//     ),
//     true
//   );

//   function sanitize(s) {
//     return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
//   }

//   function switchScene(scene) {
//     stopAutorotate();
//     scene.view.setParameters(scene.data.initialViewParameters);
//     scene.scene.switchTo();
//     startAutorotate();
//     updateSceneName(scene);
//     updateSceneList(scene);
//   }

//   function updateSceneName(scene) {
//     sceneNameElement.innerHTML = sanitize(scene.data.name);
//   }

//   function updateSceneList(scene) {
//     for (var i = 0; i < sceneElements.length; i++) {
//       var el = sceneElements[i];
//       if (el.getAttribute("data-id") === scene.data.id) {
//         el.classList.add("current");
//       } else {
//         el.classList.remove("current");
//       }
//     }
//   }

//   function showSceneList() {
//     sceneListElement.classList.add("enabled");
//     sceneListToggleElement.classList.add("enabled");
//   }

//   function hideSceneList() {
//     sceneListElement.classList.remove("enabled");
//     sceneListToggleElement.classList.remove("enabled");
//   }

//   function toggleSceneList() {
//     sceneListElement.classList.toggle("enabled");
//     sceneListToggleElement.classList.toggle("enabled");
//   }

//   function startAutorotate() {
//     if (!autorotateToggleElement.classList.contains("enabled")) {
//       return;
//     }
//     viewer.startMovement(autorotate);
//     viewer.setIdleMovement(3000, autorotate);
//   }

//   function stopAutorotate() {
//     viewer.stopMovement();
//     viewer.setIdleMovement(Infinity);
//   }

//   function toggleAutorotate() {
//     if (autorotateToggleElement.classList.contains("enabled")) {
//       autorotateToggleElement.classList.remove("enabled");
//       stopAutorotate();
//     } else {
//       autorotateToggleElement.classList.add("enabled");
//       startAutorotate();
//     }
//   }

//   function createLinkHotspotElement(hotspot) {
//     // Create wrapper element to hold icon and tooltip.
//     var wrapper = document.createElement("div");
//     wrapper.classList.add("hotspot");
//     wrapper.classList.add("link-hotspot");

//     // Create image element.
//     var icon = document.createElement("img");
//     icon.src = "img/link.png";
//     icon.classList.add("link-hotspot-icon");

//     // Set rotation transform.
//     var transformProperties = [
//       "-ms-transform",
//       "-webkit-transform",
//       "transform",
//     ];
//     for (var i = 0; i < transformProperties.length; i++) {
//       var property = transformProperties[i];
//       icon.style[property] = "rotate(" + hotspot.rotation + "rad)";
//     }

//     // Add click event handler.
//     wrapper.addEventListener("click", function () {
//       switchScene(findSceneById(hotspot.target));
//     });

//     // Prevent touch and scroll events from reaching the parent element.
//     // This prevents the view control logic from interfering with the hotspot.
//     //stopTouchAndScrollEventPropagation(wrapper);

//     // Create tooltip element.
//     var tooltip = document.createElement("div");
//     tooltip.classList.add("hotspot-tooltip");
//     tooltip.classList.add("link-hotspot-tooltip");
//     tooltip.innerHTML = findSceneDataById(hotspot.target).name;

//     wrapper.appendChild(icon);
//     wrapper.appendChild(tooltip);

//     return wrapper;
//   }

//   function createInfoHotspotElement(hotspot) {
//     // Create wrapper element to hold icon and tooltip.
//     var wrapper = document.createElement("div");
//     wrapper.classList.add("hotspot");
//     wrapper.classList.add("info-hotspot");

//     // Create hotspot/tooltip header.
//     var header = document.createElement("div");
//     header.classList.add("info-hotspot-header");

//     // Create image element.
//     var iconWrapper = document.createElement("div");
//     iconWrapper.classList.add("info-hotspot-icon-wrapper");
//     var icon = document.createElement("img");
//     icon.src = "img/info.png";
//     icon.classList.add("info-hotspot-icon");
//     iconWrapper.appendChild(icon);

//     // Create title element.
//     var titleWrapper = document.createElement("div");
//     titleWrapper.classList.add("info-hotspot-title-wrapper");
//     var title = document.createElement("div");
//     title.classList.add("info-hotspot-title");
//     title.innerHTML = hotspot.title;
//     titleWrapper.appendChild(title);

//     // Create close element.
//     var closeWrapper = document.createElement("div");
//     closeWrapper.classList.add("info-hotspot-close-wrapper");
//     var closeIcon = document.createElement("img");
//     closeIcon.src = "img/close.png";
//     closeIcon.classList.add("info-hotspot-close-icon");
//     closeWrapper.appendChild(closeIcon);

//     // Construct header element.
//     header.appendChild(iconWrapper);
//     header.appendChild(titleWrapper);
//     header.appendChild(closeWrapper);

//     // Create text element.
//     var text = document.createElement("div");
//     text.classList.add("info-hotspot-text");
//     text.innerHTML = hotspot.text;

//     // Place header and text into wrapper element.
//     wrapper.appendChild(header);
//     wrapper.appendChild(text);

//     // Create a modal for the hotspot content to appear on mobile mode.
//     var modal = document.createElement("div");
//     modal.innerHTML = wrapper.innerHTML;
//     modal.classList.add("info-hotspot-modal");
//     document.body.appendChild(modal);

//     var toggle = function () {
//       wrapper.classList.toggle("visible");
//       modal.classList.toggle("visible");
//     };

//     // Show content when hotspot is clicked.
//     wrapper
//       .querySelector(".info-hotspot-header")
//       .addEventListener("click", toggle);

//     // Hide content when close icon is clicked.
//     modal
//       .querySelector(".info-hotspot-close-wrapper")
//       .addEventListener("click", toggle);

//     // Prevent touch and scroll events from reaching the parent element.
//     // This prevents the view control logic from interfering with the hotspot.
//     //stopTouchAndScrollEventPropagation(wrapper);

//     return wrapper;
//   }

//   // Prevent touch and scroll events from reaching the parent element.

//   function stopTouchAndScrollEventPropagation(element, eventList) {
//     eventList = [
//       "touchstart",
//       "touchmove",
//       "touchend",
//       "touchcancel",
//       "wheel",
//       "mousewheel",
//     ];

//     for (var i = 0; i < eventList.length; i++) {
//       element.addEventListener(eventList[i], function (event) {
//         event.stopPropagation();
//       });
//     }
//   }

//   function findSceneById(id) {
//     for (var i = 0; i < scenes.length; i++) {
//       if (scenes[i].data.id === id) {
//         return scenes[i];
//       }
//     }
//     return null;
//   }

//   function findSceneDataById(id) {
//     // for (var i = 0; i < data[product].length; i++) {
//     //   if (data[product][i].id === id) {
//     //     return data[product][i];
//     //   }
//     // }
//     return null;
//   }

//   // Display the initial scene.
//   switchScene(scenes[0]);
// })();
