import { Component, ElementRef, OnInit } from '@angular/core';
import { Marzipano } from 'marzipano';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { HttpClient, HttpEventType, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UploadFilesService } from 'src/app/services/upload-files.service';


@Component({
  selector: 'app-upload-property-detail',
  templateUrl: './upload-property-detail.component.html',
  styleUrls: ['./upload-property-detail.component.scss']
})


export class UploadPropertyDetailComponent {
  pano: any;
  viewer: any;
  currentSceneName: any;
  maxSize: any;
  maxDimensions: string;
  scene: any;
  private element: any;



  selectedFiles: FileList;
  progressInfos = [];
  message = '';

  fileInfos: Observable<any>;

  ngOnInit(): void {
    // move element to bottom of page (just before </body>) so it can be displayed above everything else
    document.body.appendChild(this.element);
    this.fileInfos = this.uploadService.getFiles();


    // close modal on background click
    this.element.addEventListener('click', el => {
        if (el.target.className === 'jw-modal') {
            this.close();
        }
    });



  }


  title = 'appBootstrap';

  closeResult: string;

  constructor(private modalService: NgbModal, private el: ElementRef,private http: HttpClient,private uploadService: UploadFilesService) {
    this.element = el.nativeElement;
  }


   // open modal

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  // close modal
  close(): void {
    this.element.style.display = 'none';
    document.body.classList.remove('modal-basic-title');
  }


  // added file upload code
  selectFiles(event) {
    this.progressInfos = [];
    this.selectedFiles = event.target.files;
  }
  uploadFiles() {
    this.message = '';

    for (let i = 0; i < this.selectedFiles.length; i++) {
      this.upload(i, this.selectedFiles[i]);
    }
  }
  upload(idx, file) {
    this.progressInfos[idx] = { value: 0, fileName: file.name };

    this.uploadService.upload(file).subscribe(
      event => {
        if (event.type === HttpEventType.UploadProgress) {
          this.progressInfos[idx].value = Math.round(100 * event.loaded / event.total);
        } else if (event instanceof HttpResponse) {
          this.fileInfos = this.uploadService.getFiles();
        }
      },
      err => {
        this.progressInfos[idx].value = 0;
        this.message = 'Could not upload the file:' + file.name;
      });
  }

}
